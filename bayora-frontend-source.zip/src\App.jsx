
import { useCallback, useEffect, useState } from "react";
import {
  Activity, Shield, ShieldAlert, LayoutDashboard, Swords,
  Users, FileCheck2, Settings, CircleCheck, CircleX,
  RefreshCw, Terminal, ArrowUpRight, LockKeyhole,
  Zap, Clock3, ChevronRight
} from "lucide-react";
import "./App.css";

const API = "http://127.0.0.1:8000";

const NAV = [
  { id: "overview", label: "Overview", icon: LayoutDashboard },
  { id: "simulator", label: "Attack Simulator", icon: Swords },
  { id: "teams", label: "Team Isolation", icon: Users },
  { id: "audit", label: "Audit Integrity", icon: FileCheck2 },
];

function StatusDot({ online }) {
  return <span className={`status-dot ${online ? "online" : "offline"}`} />;
}

function Metric({ icon: Icon, label, value, detail, tone = "purple" }) {
  return (
    <div className="metric-card">
      <div className={`metric-icon ${tone}`}><Icon size={20} /></div>
      <div className="metric-label">{label}</div>
      <div className="metric-value">{value}</div>
      <div className="metric-detail">{detail}</div>
    </div>
  );
}

function App() {
  const [page, setPage] = useState("overview");
  const [apiOnline, setApiOnline] = useState(false);
  const [checking, setChecking] = useState(false);
  const [prompt, setPrompt] = useState("");
  const [verdict, setVerdict] = useState(null);
  const [testing, setTesting] = useState(false);
  const [error, setError] = useState("");
  const [events, setEvents] = useState([]);
  const [counts, setCounts] = useState({ checked: 0, blocked: 0, allowed: 0 });

  const [team, setTeam] = useState("red");
  const [teamToken, setTeamToken] = useState("");
  const [teamResult, setTeamResult] = useState(null);
  const [teamLoading, setTeamLoading] = useState(false);

  const [adminToken, setAdminToken] = useState("");
  const [auditResult, setAuditResult] = useState(null);
  const [auditLoading, setAuditLoading] = useState(false);

  const checkHealth = useCallback(async () => {
    setChecking(true);
    try {
      const response = await fetch(`${API}/health`);
      setApiOnline(response.ok);
    } catch {
      setApiOnline(false);
    } finally {
      setChecking(false);
    }
  }, []);

  useEffect(() => {
    checkHealth();
    const timer = setInterval(checkHealth, 15000);
    return () => clearInterval(timer);
  }, [checkHealth]);

  async function testPrompt(e) {
    e.preventDefault();
    if (!prompt.trim()) return;

    setTesting(true);
    setError("");
    setVerdict(null);

    try {
      const response = await fetch(`${API}/guard/input`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: prompt.trim() }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.detail || `API returned HTTP ${response.status}`);
      }

      const allowed = typeof data.allowed === "boolean"
        ? data.allowed
        : typeof data.blocked === "boolean"
          ? !data.blocked
          : null;

      const result = { ...data, allowed, httpStatus: response.status };
      setVerdict(result);
      setCounts((old) => ({
        checked: old.checked + 1,
        allowed: old.allowed + (allowed === true ? 1 : 0),
        blocked: old.blocked + (allowed === false ? 1 : 0),
      }));

      setEvents((old) => [
        {
          id: Date.now(),
          time: new Date().toLocaleTimeString(),
          outcome: allowed === true ? "Allowed" : allowed === false ? "Blocked" : "Reviewed",
          prompt: prompt.trim().slice(0, 100),
        },
        ...old,
      ].slice(0, 8));
    } catch (err) {
      setError(`${err.message}. Check that Bayora's API is running and CORS permits this frontend.`);
    } finally {
      setTesting(false);
    }
  }

  async function testTeamAccess(e) {
    e.preventDefault();
    setTeamLoading(true);
    setTeamResult(null);
    try {
      const response = await fetch(`${API}/bayora/private/${team}`, {
        headers: { Authorization: `Bearer ${teamToken}` },
      });
      const data = await response.json().catch(() => ({}));
      setTeamResult({ status: response.status, data });
    } catch (err) {
      setTeamResult({ error: err.message });
    } finally {
      setTeamLoading(false);
    }
  }

  async function verifyAudit(e) {
    e.preventDefault();
    setAuditLoading(true);
    setAuditResult(null);
    try {
      const response = await fetch(`${API}/bayora/audit/verify`, {
        headers: { Authorization: `Bearer ${adminToken}` },
      });
      const data = await response.json().catch(() => ({}));
      setAuditResult({ status: response.status, data });
    } catch (err) {
      setAuditResult({ error: err.message });
    } finally {
      setAuditLoading(false);
    }
  }

  const title = NAV.find((item) => item.id === page)?.label || "Overview";

  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark"><Shield size={24} /></div>
          <div>
            <div className="brand-name">bayora<span>.</span></div>
            <div className="brand-caption">AI SECURITY PLATFORM</div>
          </div>
        </div>

        <div className="nav-caption">WORKSPACE</div>
        <nav className="nav-list">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              className={`nav-item ${page === id ? "active" : ""}`}
              onClick={() => setPage(id)}
            >
              <Icon size={18} />
              <span>{label}</span>
              {page === id && <ChevronRight size={15} className="nav-arrow" />}
            </button>
          ))}
        </nav>

        <div className="sidebar-bottom">
          <div className="environment-card">
            <div className="environment-icon"><LockKeyhole size={17} /></div>
            <div>
              <strong>Local environment</strong>
              <span>Development mode</span>
            </div>
          </div>
          <div className="sidebar-footer">
            <span className="footer-pulse" /> BAYORA SECURITY CONSOLE
            <span className="version">v0.1</span>
          </div>
        </div>
      </aside>

      <main className="main-area">
        <header className="topbar">
          <div className="breadcrumb">Bayora <span>/</span> {title}</div>
          <div className="topbar-right">
            <div className="api-status">
              <StatusDot online={apiOnline} />
              <span>API {apiOnline ? "Connected" : "Offline"}</span>
            </div>
            <button className="icon-button" title="Refresh API status" onClick={checkHealth}>
              <RefreshCw size={17} className={checking ? "spin" : ""} />
            </button>
            <div className="avatar">B</div>
          </div>
        </header>

        <div className="page-content">
          {page === "overview" && (
            <>
              <div className="page-heading">
                <div>
                  <div className="eyebrow"><Activity size={14} /> SECURITY OPERATIONS</div>
                  <h1>Security overview<span>.</span></h1>
                  <p>Monitor guardrail decisions and test Bayora's security controls.</p>
                </div>
                <button className="primary-button" onClick={() => setPage("simulator")}>
                  <Zap size={16} /> Test a prompt
                </button>
              </div>

              <div className="notice">
                <div className="notice-icon"><ShieldAlert size={19} /></div>
                <div>
                  <strong>Security testing environment</strong>
                  <p>Metrics below reflect tests run during this browser session, not total production traffic.</p>
                </div>
                <span className="notice-tag">LOCAL</span>
              </div>

              <div className="metrics-grid">
                <Metric icon={Activity} label="Prompts tested" value={counts.checked} detail="This browser session" />
                <Metric icon={ShieldAlert} label="Blocked" value={counts.blocked} detail="Input guardrail decisions" tone="red" />
                <Metric icon={CircleCheck} label="Allowed" value={counts.allowed} detail="Input guardrail decisions" tone="green" />
                <Metric icon={Zap} label="API status" value={apiOnline ? "Online" : "Offline"} detail={apiOnline ? "Health check succeeded" : "Check backend connection"} tone="blue" />
              </div>

              <div className="content-grid">
                <section className="panel">
                  <div className="panel-heading">
                    <div><h2>Quick security test</h2><p>Run a prompt through the input guardrail.</p></div>
                    <span className="panel-icon"><Swords size={18} /></span>
                  </div>
                  <form onSubmit={testPrompt}>
                    <label className="field-label" htmlFor="quick-prompt">TEST PROMPT</label>
                    <textarea id="quick-prompt" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Enter a prompt to evaluate..." rows={4} />
                    <button className="primary-button full-button" disabled={testing || !prompt.trim()}>
                      {testing ? <RefreshCw size={16} className="spin" /> : <Shield size={16} />}
                      {testing ? "Evaluating..." : "Evaluate prompt"}
                    </button>
                  </form>
                  {error && <div className="inline-error">{error}</div>}
                  {verdict && <Verdict result={verdict} />}
                </section>

                <section className="panel">
                  <div className="panel-heading">
                    <div><h2>Security controls</h2><p>Capabilities currently implemented.</p></div>
                    <span className="panel-icon"><LockKeyhole size={18} /></span>
                  </div>
                  <div className="control-list">
                    {[
                      ["Prompt input guardrails", "Active"],
                      ["Output safety checks", "Active"],
                      ["Red/blue resource access", "Implemented"],
                      ["Rate limiting", "Implemented"],
                      ["Hash-chain audit verification", "Implemented"],
                    ].map(([name, status]) => (
                      <div className="control-row" key={name}>
                        <div className="control-check"><CircleCheck size={15} /></div>
                        <span>{name}</span><span className="control-status">{status}</span>
                      </div>
                    ))}
                  </div>
                  <button className="text-button" onClick={() => setPage("teams")}>Explore access controls <ArrowUpRight size={15} /></button>
                </section>
              </div>

              <section className="panel events-panel">
                <div className="panel-heading">
                  <div><h2>Recent test activity</h2><p>Requests made from this dashboard.</p></div>
                  <span className="subtle-count">{events.length} events</span>
                </div>
                {events.length === 0 ? (
                  <div className="empty-state">
                    <div className="empty-icon"><Terminal size={21} /></div>
                    <strong>No test activity yet</strong>
                    <p>Run a prompt test to see real results here.</p>
                  </div>
                ) : (
                  <div className="table-wrap">
                    <table>
                      <thead><tr><th>RESULT</th><th>PROMPT</th><th>TIME</th></tr></thead>
                      <tbody>{events.map((event) => (
                        <tr key={event.id}>
                          <td><span className={`event-badge ${event.outcome.toLowerCase()}`}>{event.outcome}</span></td>
                          <td className="prompt-cell">{event.prompt}</td>
                          <td className="time-cell"><Clock3 size={13} /> {event.time}</td>
                        </tr>
                      ))}</tbody>
                    </table>
                  </div>
                )}
              </section>
            </>
          )}

          {page === "simulator" && (
            <>
              <div className="page-heading">
                <div><div className="eyebrow"><Swords size={14} /> RED TEAM WORKSPACE</div><h1>Attack simulator<span>.</span></h1><p>Submit test inputs and inspect the actual guardrail response.</p></div>
              </div>
              <section className="panel simulator-panel">
                <div className="panel-heading"><div><h2>Input security evaluation</h2><p>Calls the live POST /guard/input endpoint.</p></div><span className="panel-icon"><Shield size={18} /></span></div>
                <form onSubmit={testPrompt}>
                  <label className="field-label" htmlFor="attack-prompt">PROMPT TO EVALUATE</label>
                  <textarea id="attack-prompt" className="large-textarea" value={prompt} onChange={(e) => setPrompt(e.target.value)} placeholder="Try a benign prompt or a simulated prompt-injection attempt..." rows={8} />
                  <div className="form-footer"><span>{prompt.length.toLocaleString()} characters</span><button className="primary-button" disabled={testing || !prompt.trim()}>{testing ? <RefreshCw size={16} className="spin" /> : <Shield size={16} />}{testing ? "Evaluating..." : "Run evaluation"}</button></div>
                </form>
                {error && <div className="inline-error">{error}</div>}
                {verdict && <Verdict result={verdict} />}
                <div className="hint-box"><ShieldAlert size={17} /><span>Use only harmless, authorized test prompts. This tool tests the input guardrail; it does not execute an attack against an external system.</span></div>
              </section>
            </>
          )}

          {page === "teams" && (
            <>
              <div className="page-heading"><div><div className="eyebrow"><Users size={14} /> ACCESS CONTROL</div><h1>Team isolation<span>.</span></h1><p>Test authenticated access to Bayora's team-specific resources.</p></div></div>
              <div className="notice"><div className="notice-icon"><LockKeyhole size={19} /></div><div><strong>Use development tokens only</strong><p>Tokens are held in this page's temporary state and are not saved to browser storage. Never use production secrets here.</p></div></div>
              <section className="panel">
                <div className="panel-heading"><div><h2>Private resource access test</h2><p>Calls GET /bayora/private/{team}.</p></div><span className="panel-icon"><LockKeyhole size={18} /></span></div>
                <form onSubmit={testTeamAccess}>
                  <label className="field-label" htmlFor="team-select">TEAM RESOURCE</label>
                  <select id="team-select" value={team} onChange={(e) => { setTeam(e.target.value); setTeamResult(null); }}>
                    <option value="red">Red team resource</option><option value="blue">Blue team resource</option>
                  </select>
                  <label className="field-label" htmlFor="team-token">BEARER TOKEN</label>
                  <input id="team-token" type="password" autoComplete="off" value={teamToken} onChange={(e) => setTeamToken(e.target.value)} placeholder="Enter the matching development token" required />
                  <button className="primary-button" disabled={teamLoading || !teamToken.trim()}>{teamLoading ? "Checking access..." : "Test resource access"}</button>
                </form>
                {teamResult && <div className={`result-box ${teamResult.status === 200 ? "result-good" : "result-bad"}`}><strong>{teamResult.error ? "Request failed" : `HTTP ${teamResult.status}`}</strong><pre>{JSON.stringify(teamResult.data || { error: teamResult.error }, null, 2)}</pre></div>}
                <div className="hint-box"><ShieldAlert size={17} /><span>Use the configured development token for the selected team. A 403 when accessing the other team's resource is an expected security control.</span></div>
              </section>
            </>
          )}

          {page === "audit" && (
            <>
              <div className="page-heading"><div><div className="eyebrow"><FileCheck2 size={14} /> AUDIT VERIFICATION</div><h1>Audit integrity<span>.</span></h1><p>Verify the integrity of Bayora's hash-chained audit log.</p></div></div>
              <section className="panel">
                <div className="panel-heading"><div><h2>Verify audit chain</h2><p>Calls GET /bayora/audit/verify using admin authentication.</p></div><span className="panel-icon"><FileCheck2 size={18} /></span></div>
                <form onSubmit={verifyAudit}>
                  <label className="field-label" htmlFor="admin-token">AUDIT ADMIN TOKEN</label>
                  <input id="admin-token" type="password" autoComplete="off" value={adminToken} onChange={(e) => setAdminToken(e.target.value)} placeholder="Enter the configured admin development token" required />
                  <button className="primary-button" disabled={auditLoading || !adminToken.trim()}>{auditLoading ? "Verifying..." : "Verify audit integrity"}</button>
                </form>
                {auditResult && <div className={`result-box ${auditResult.status === 200 && auditResult.data?.valid !== false ? "result-good" : "result-bad"}`}><strong>{auditResult.error ? "Verification request failed" : `HTTP ${auditResult.status}`}</strong><pre>{JSON.stringify(auditResult.data || { error: auditResult.error }, null, 2)}</pre></div>}
                <div className="hint-box"><ShieldAlert size={17} /><span>Hash-chain verification can detect record modification. It does not make the log tamper-proof against an attacker who can rewrite the entire log and recompute hashes.</span></div>
              </section>
            </>
          )}

          <footer className="page-footer"><span> BAYORA <span className="footer-separator">/</span> AI SAFETY VALIDATION INFRASTRUCTURE</span><span>Built for security testing · Development environment</span></footer>
        </div>
      </main>
    </div>
  );
}

function Verdict({ result }) {
  const allowed = result.allowed;
  return (
    <div className={`verdict-card ${allowed === true ? "verdict-allowed" : allowed === false ? "verdict-blocked" : "verdict-unknown"}`}>
      <div className="verdict-top">
        {allowed === true ? <CircleCheck size={21} /> : allowed === false ? <CircleX size={21} /> : <ShieldAlert size={21} />}
        <div><strong>{allowed === true ? "Input allowed" : allowed === false ? "Input blocked" : "Response received"}</strong><span>{allowed === null ? "Inspect the raw verdict below." : "Actual response from Bayora's API"}</span></div>
        <span className="http-chip">HTTP {result.httpStatus}</span>
      </div>
      <div className="verdict-details">
        <div><span>Decision</span><strong>{allowed === true ? "ALLOW" : allowed === false ? "BLOCK" : "UNKNOWN"}</strong></div>
        <div><span>Reasons</span><strong>{Array.isArray(result.reasons) && result.reasons.length ? result.reasons.join(", ") : "No reasons supplied"}</strong></div>
      </div>
      <details><summary>View full API response</summary><pre>{JSON.stringify(result, null, 2)}</pre></details>
    </div>
  );
}

export default App;
